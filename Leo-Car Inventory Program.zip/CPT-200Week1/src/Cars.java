public class Cars
{
	private String prodBrand; // product brand
	private String prodType; // product type
	private String prodName; // product name
	private String prodColor; //product color
	private String prodNumber; // product license number
	private double unitPrice; // price per unit 
    private int unitsTotal; // total units in stock
    private double totalInventory; // amount of total inventory
    
    // constructor
    public Cars( String brand, String type, String name, String color, double price, String number, int total)
    {
    	 prodBrand = brand;
    	 prodType = type;
    	 prodName = name;
    	 prodColor = color;
         prodNumber = number;
         
         setUnitsTotal (total);
         setUnitPrice (price);
         
     }// end constructor
    
    /* 
     * order of print is as follows:
     * Brand, Type, Name, Color, License Number, 
     * Price, Stock, and Total Inventory Amount
     */
    
    // Brand
    public void setProdBrand(String brand)
    {
    	prodBrand = brand;
    }
    public String getProdBrand()
    {
    	return prodBrand;
    }
    
    // Type
    public void setProdType(String type)
    {
    	prodType = type;
    }
    public String getProdType()
    {
    	return prodType;
    }
    
    // Name
    public void setProdName(String name)
    {
    	prodName = name;
    } 
    public String getProdName()
    {
    	return prodName;
    }
    
    // Color
    public void setProdColor(String color) 
    {
    	prodColor = color;
    }
    public String getProdColor() 
    {
    	return prodColor;
    }
    
    // Price
    public void setUnitPrice(double price)
    {
    	unitPrice = price;
    }
    public double getUnitPrice()
    {
    	return unitPrice;
    }
    
    // Number
    public void setProdNumber(String number)
    {
    	prodNumber = number;
    } 
    public String getProdNumber()
    {
    	return prodNumber;
    }
    
    // Unit total
    public void setUnitsTotal(int total)
    {
    	unitsTotal = total;
    } 
    public int getUnitsTotal()
    {
    	return unitsTotal;
    }
    
    // Value
    public double getValue()
    {
    	return unitsTotal * unitPrice;
    }
    
} // end class Cars