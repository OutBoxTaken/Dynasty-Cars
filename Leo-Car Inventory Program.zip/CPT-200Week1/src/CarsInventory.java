public class  CarsInventory
{
     public static void main( String args [ ])
     {
          // dummy manual values -- Needs to change to a read/write type system for ease of use
          Cars product1 = new Cars(
               "Dodge", "Coupe", "Viper GTS", "Blue", 65000, "GJE 631", 12);
          Cars product2 = new Cars(
                  "Ram", "Truck", "Big Boy Jankins", "Red", 70000, "BIG RED", 1);
          
          // get car information
          System.out.println(
                  "Dynasty Cars Used Car Inventory");
          
          System.out.println();
          
          System.out.println(
                  "Product 1 Test");
          System.out.printf( "%s %s\n", "Product Brand:",
                  product1.getProdBrand() );
          System.out.printf( "%s %s\n", "Product Type:",
                  product1.getProdType() );
          System.out.printf( "%s %s\n", "Product Name:",
                  product1.getProdName() );
          System.out.printf( "%s %s\n", "Product Color:",
                  product1.getProdColor() );
          System.out.printf( "%s %s\n", "Product License Number:", 
                  product1.getProdNumber() );
          System.out.printf( "%s $%g\n", "Price Per Unit:",
                  product1.getUnitPrice() );
          System.out.printf( "%s %d\n", "Total Units in Stock:",
                  product1.getUnitsTotal() );
          System.out.printf( "%s $%g\n", "Total Inventory Dollar Amount:",
        		  product1.getValue() );
          
          System.out.println();
          
          System.out.println(
                  "Product 2 Test");
          System.out.printf( "%s %s\n", "Product Brand:",
                  product2.getProdBrand() );
          System.out.printf( "%s %s\n", "Product Type:",
                  product2.getProdType() );
          System.out.printf( "%s %s\n", "Product Name:",
                  product2.getProdName() );
          System.out.printf( "%s %s\n", "Product Color:",
                  product2.getProdColor() );
          System.out.printf( "%s %s\n", "Product License Number:", 
                  product2.getProdNumber() );
          System.out.printf( "%s $%g\n", "Price Per Unit:",
                  product2.getUnitPrice() );
          System.out.printf( "%s %d\n", "Total Units in Stock:",
                  product2.getUnitsTotal() );
          System.out.printf( "%s $%g\n", "Total Inventory Dollar Amount:",
        		  product2.getValue() );
          
     } // end main method
} // end class CarsInventory